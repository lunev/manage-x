const A="Chrome Extension Starter",a={UPDATES_AVAILABLE:"Updates available"};export{A,a as S};
